;var mp_new_product_search = [];
            var mp_most_viewed_products = [];
            var mp_bestsellers = [];