<?php
namespace Enjoyp\Seller\Block;
class Prelaunch extends \Magento\Framework\View\Element\Template
{

}