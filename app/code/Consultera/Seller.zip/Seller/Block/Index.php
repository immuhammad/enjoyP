<?php
namespace Enjoyp\Seller\Block;
class Index extends \Magento\Framework\View\Element\Template
{

}
